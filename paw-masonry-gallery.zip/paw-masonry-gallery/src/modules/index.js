import Gallery from './gallery';

export default [Gallery];
