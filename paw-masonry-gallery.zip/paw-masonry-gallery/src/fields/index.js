import Layout from './layout';
import Separator from './separator';

export default [Layout, Separator];
